import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { IProduct } from '../product.interface';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
products:IProduct[];


//Injecting product service
  constructor(private _productService:ProductService) { }


  ngOnInit() {
    this._productService.getProducts().subscribe((data) => {this.products = data;
     this._productService.setData(this.products);
    }, (httperror) => console.log(httperror));
  }

  
  //Call to method in service
    deleteProduct(index:number){
      this._productService.deleteProduct(index);
    }
   

}
