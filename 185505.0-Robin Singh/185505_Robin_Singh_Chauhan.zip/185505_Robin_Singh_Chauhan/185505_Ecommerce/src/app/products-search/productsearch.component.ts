import { Component, OnInit } from '@angular/core';
import { IProduct } from '../product.interface';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-productsearch',
  templateUrl: './productsearch.component.html',
  styleUrls: ['./productsearch.component.css']
})
export class ProductsearchComponent implements OnInit {

  products: IProduct[];
  searchItem: string;
  temp: string;
  
  //Injecting product Service
  constructor(private _productService: ProductService) { }


  
  ngOnInit() {
    this._productService.getProducts().subscribe(data=>this.products=data)
    };
  

  searchItemFun() {
    this.searchItem = this.temp;
  }

}
