import { Pipe, PipeTransform } from '@angular/core';
import { IProduct } from './product.interface';

@Pipe({
  name: 'product'
})
export class ProductPipe implements PipeTransform {

  
  //Filter Pipe 
  
  transform(products:IProduct[],searchItem:string): any {
    
    searchItem=searchItem.toLowerCase();
    return products.filter(
      product=>(product.name.toLowerCase().startsWith(searchItem)||product.category.toLowerCase().startsWith(searchItem)));
  }

}
