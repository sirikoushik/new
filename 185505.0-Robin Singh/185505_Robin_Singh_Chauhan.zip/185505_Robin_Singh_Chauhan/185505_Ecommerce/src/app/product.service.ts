import { Injectable } from '@angular/core';
import { IProduct } from './product.interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductlistComponent } from './products-list/productlist.component';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  
  products: IProduct[];
 
  constructor(private http:HttpClient) { }
  private _url:string = "./assets/db.json"; //Url to json file

  //This method recieves data from db.json using Http service
  getProducts():Observable<IProduct[]>{
    return this.http.get<IProduct[]>(this._url);
  }

  //This methods provides 
  getData(){
    return this.products;
  }

  
  //Sets data to service local object
  setData(productsData:IProduct[]){
    this.products=productsData;
    
  }

  
  //Delte item from local object
  deleteProduct(index:number){
    this.products.splice(index,1);
  }

}